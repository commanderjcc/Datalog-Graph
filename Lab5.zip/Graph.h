//
// Created by Josh Christensen on 4/4/23.
//

#ifndef DL_GRAPH_GRAPH_H
#define DL_GRAPH_GRAPH_H
#include "Node.h"
#include <map>
#include <string>

using namespace std;

class Graph {
private:

    map<int,Node> nodes;

public:

    explicit Graph(int size) {
        for (int nodeID = 0; nodeID < size; nodeID++)
            nodes[nodeID] = Node();
    }

    void addEdge(int fromNodeID, int toNodeID) {
        nodes[fromNodeID].addEdge(toNodeID);
    }

    string toString();
};


#endif //DL_GRAPH_GRAPH_H
