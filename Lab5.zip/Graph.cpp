//
// Created by Josh Christensen on 4/4/23.
//

#include "Graph.h"
#include <sstream>

string Graph::toString() {
    stringstream ss;
    for (auto& pair: nodes) {
        int nodeID = pair.first;
        Node node = pair.second;

        ss << "R" << nodeID << ":" << node.toString() << endl;
    }


    return ss.str();
}
